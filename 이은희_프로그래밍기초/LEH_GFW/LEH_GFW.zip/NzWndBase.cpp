#include "NzWndBase.h"
#include <iostream>

LRESULT CALLBACK NzWndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
{

}

bool Create(const wchar_t* className, const wchar_t* windowName, int width, int height)
{

}

void Destroy()
{

}
